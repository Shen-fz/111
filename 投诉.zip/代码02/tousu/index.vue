<template>
  <view class="container">
    <view class="page-title">社区投诉</view>
    <view class="form-item">
      <label>姓名：</label>
      <input v-model="formData.tousuName" placeholder="请输入您的姓名" />
    </view>
    <view class="form-item">
      <label>联系电话：</label>
      <input v-model="formData.tousuPhone" placeholder="请输入您的联系电话" />
    </view>
    <view class="form-item">
      <label>投诉对象：</label>
      <input v-model="formData.tousuObject" placeholder="请输入投诉对象" />
    </view>
    <view class="form-item">
      <label>投诉内容：</label>
      <textarea v-model="formData.tousuContent" placeholder="请详细描述您的投诉内容"></textarea>
    </view>
    <button @click="submitForm">提交投诉</button>
  </view>
</template>

<script>
import { addTousu } from '../../../api/system/tousu.js';

export default {
  data() {
    return {
      formData: {
        tousuName: '',
        tousuPhone: '',
        tousuObject: '',
        tousuContent: ''
      }
    };
  },
  methods: {
    submitForm() {
      const { tousuName, tousuPhone, tousuObject, tousuContent } = this.formData;
      if (!tousuName || !tousuPhone || !tousuObject || !tousuContent) {
        uni.showToast({
          title: '请填写完整信息',
          icon: 'none'
        });
        return;
      }
      console.log('请求数据:', this.formData); // 打印请求数据
      const localUni = uni; // 将 uni 对象赋值给局部变量
      addTousu(this.formData)
        .then(response => {
          console.log('提交成功', response);
          localUni.showToast({
            title: '提交成功',
            icon: 'success'
          });
          this.formData = {
            tousuName: '',
            tousuPhone: '',
            tousuObject: '',
            tousuContent: ''
          };
        })
        .catch(error => {
          let errorMessage = '提交失败';
          if (typeof error === 'string') {
            errorMessage += ': ' + error;
          } else if (error && error.message) {
            errorMessage += ': ' + error.message;
          }
          console.error(errorMessage);
          localUni.showToast({
            title: errorMessage,
            icon: 'none'
          });
        });
    }
  }
};
</script>

<style>
.container {
  padding: 20px;
}
.form-item {
  margin-bottom: 15px;
}
label {
  display: block;
  margin-bottom: 5px;
}
input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}
textarea {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  min-height: 120px;
}
button {
  width: 100%;
  padding: 10px;
  background-color: #007aff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}
</style>