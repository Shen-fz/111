CREATE TABLE tousu (
    id INT AUTO_INCREMENT PRIMARY KEY COMMENT 'id',
    tousu_name VARCHAR(255) COMMENT '姓名',
    tousu_phone VARCHAR(255) COMMENT '联系电话',
    tousu_object VARCHAR(255) COMMENT '投诉对象',
    tousu_content TEXT COMMENT '投诉内容'
) COMMENT '投诉记录表';

INSERT INTO tousu (tousu_name, tousu_phone, tousu_object, tousu_content)
VALUES ('张三', '18888888888', '物业', '小区卫生不好');