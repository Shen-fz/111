package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.Tousu;

/**
 * 投诉记录Service接口
 *
 * @author ruoyi
 * @date 2025-04-10
 */
public interface ITousuService
{
    /**
     * 查询投诉记录
     *
     * @param id 投诉记录主键
     * @return 投诉记录
     */
    public Tousu selectTousuById(Long id);

    /**
     * 查询投诉记录列表
     *
     * @param tousu 投诉记录
     * @return 投诉记录集合
     */
    public List<Tousu> selectTousuList(Tousu tousu);

    /**
     * 新增投诉记录
     *
     * @param tousu 投诉记录
     * @return 结果
     */
    public int insertTousu(Tousu tousu);

    /**
     * 修改投诉记录
     *
     * @param tousu 投诉记录
     * @return 结果
     */
    public int updateTousu(Tousu tousu);

    /**
     * 批量删除投诉记录
     *
     * @param ids 需要删除的投诉记录主键集合
     * @return 结果
     */
    public int deleteTousuByIds(Long[] ids);

    /**
     * 删除投诉记录信息
     *
     * @param id 投诉记录主键
     * @return 结果
     */
    public int deleteTousuById(Long id);
}
