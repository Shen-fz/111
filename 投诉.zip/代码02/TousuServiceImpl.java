package com.ruoyi.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.TousuMapper;
import com.ruoyi.system.domain.Tousu;
import com.ruoyi.system.service.ITousuService;

/**
 * 投诉记录Service业务层处理
 *
 * @author ruoyi
 * @date 2025-04-10
 */
@Service
public class TousuServiceImpl implements ITousuService
{
    @Autowired
    private TousuMapper tousuMapper;

    /**
     * 查询投诉记录
     *
     * @param id 投诉记录主键
     * @return 投诉记录
     */
    @Override
    public Tousu selectTousuById(Long id)
    {
        return tousuMapper.selectTousuById(id);
    }

    /**
     * 查询投诉记录列表
     *
     * @param tousu 投诉记录
     * @return 投诉记录
     */
    @Override
    public List<Tousu> selectTousuList(Tousu tousu)
    {
        return tousuMapper.selectTousuList(tousu);
    }

    /**
     * 新增投诉记录
     *
     * @param tousu 投诉记录
     * @return 结果
     */
    @Override
    public int insertTousu(Tousu tousu)
    {
        return tousuMapper.insertTousu(tousu);
    }

    /**
     * 修改投诉记录
     *
     * @param tousu 投诉记录
     * @return 结果
     */
    @Override
    public int updateTousu(Tousu tousu)
    {
        return tousuMapper.updateTousu(tousu);
    }

    /**
     * 批量删除投诉记录
     *
     * @param ids 需要删除的投诉记录主键
     * @return 结果
     */
    @Override
    public int deleteTousuByIds(Long[] ids)
    {
        return tousuMapper.deleteTousuByIds(ids);
    }

    /**
     * 删除投诉记录信息
     *
     * @param id 投诉记录主键
     * @return 结果
     */
    @Override
    public int deleteTousuById(Long id)
    {
        return tousuMapper.deleteTousuById(id);
    }
}
