package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 投诉记录对象 tousu
 *
 * @author ruoyi
 * @date 2025-04-10
 */
public class Tousu extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private Long id;

    /** 姓名 */
    @Excel(name = "姓名")
    private String tousuName;

    /** 联系电话 */
    @Excel(name = "联系电话")
    private String tousuPhone;

    /** 投诉对象 */
    @Excel(name = "投诉对象")
    private String tousuObject;

    /** 投诉内容 */
    @Excel(name = "投诉内容")
    private String tousuContent;

    public void setId(Long id)
    {
        this.id = id;
    }

    public Long getId()
    {
        return id;
    }

    public void setTousuName(String tousuName)
    {
        this.tousuName = tousuName;
    }

    public String getTousuName()
    {
        return tousuName;
    }

    public void setTousuPhone(String tousuPhone)
    {
        this.tousuPhone = tousuPhone;
    }

    public String getTousuPhone()
    {
        return tousuPhone;
    }

    public void setTousuObject(String tousuObject)
    {
        this.tousuObject = tousuObject;
    }

    public String getTousuObject()
    {
        return tousuObject;
    }

    public void setTousuContent(String tousuContent)
    {
        this.tousuContent = tousuContent;
    }

    public String getTousuContent()
    {
        return tousuContent;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("id", getId())
                .append("tousuName", getTousuName())
                .append("tousuPhone", getTousuPhone())
                .append("tousuObject", getTousuObject())
                .append("tousuContent", getTousuContent())
                .toString();
    }
}
