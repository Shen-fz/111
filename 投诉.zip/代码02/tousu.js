import request from '@/utils/request'

// 查询投诉记录列表
export function listTousu(query) {
  return request({
    url: '/system/tousu/list',
    method: 'get',
    params: query
  })
}

// 查询投诉记录详细
export function getTousu(id) {
  return request({
    url: '/system/tousu/' + id,
    method: 'get'
  })
}

// 新增投诉记录
export function addTousu(data) {
  return request({
    url: '/system/tousu',
    method: 'post',
    data: data
  })
}

// 修改投诉记录
export function updateTousu(data) {
  return request({
    url: '/system/tousu',
    method: 'put',
    data: data
  })
}

// 删除投诉记录
export function delTousu(id) {
  return request({
    url: '/system/tousu/' + id,
    method: 'delete'
  })
}
