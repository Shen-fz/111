import request from '@/utils/request'

// 查询维修相关信息列表
export function listWeixiu(query) {
  return request({
    url: '/system/weixiu/list',
    method: 'get',
    params: query
  })
}

// 查询维修相关信息详细
export function getWeixiu(id) {
  return request({
    url: '/system/weixiu/' + id,
    method: 'get'
  })
}

// 新增维修相关信息
export function addWeixiu(data) {
  return request({
    url: '/system/weixiu',
    method: 'post',
    data: data
  })
}

// 修改维修相关信息
export function updateWeixiu(data) {
  return request({
    url: '/system/weixiu',
    method: 'put',
    data: data
  })
}

// 删除维修相关信息
export function delWeixiu(id) {
  return request({
    url: '/system/weixiu/' + id,
    method: 'delete'
  })
}
