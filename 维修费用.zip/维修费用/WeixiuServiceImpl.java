package com.ruoyi.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.WeixiuMapper;
import com.ruoyi.system.domain.Weixiu;
import com.ruoyi.system.service.IWeixiuService;

/**
 * 维修相关信息Service业务层处理
 *
 * @author ruoyi
 * @date 2025-04-07
 */
@Service
public class WeixiuServiceImpl implements IWeixiuService
{
    @Autowired
    private WeixiuMapper weixiuMapper;

    /**
     * 查询维修相关信息
     *
     * @param id 维修相关信息主键
     * @return 维修相关信息
     */
    @Override
    public Weixiu selectWeixiuById(Long id)
    {
        return weixiuMapper.selectWeixiuById(id);
    }

    /**
     * 查询维修相关信息列表
     *
     * @param weixiu 维修相关信息
     * @return 维修相关信息
     */
    @Override
    public List<Weixiu> selectWeixiuList(Weixiu weixiu)
    {
        return weixiuMapper.selectWeixiuList(weixiu);
    }

    /**
     * 新增维修相关信息
     *
     * @param weixiu 维修相关信息
     * @return 结果
     */
    @Override
    public int insertWeixiu(Weixiu weixiu)
    {
        return weixiuMapper.insertWeixiu(weixiu);
    }

    /**
     * 修改维修相关信息
     *
     * @param weixiu 维修相关信息
     * @return 结果
     */
    @Override
    public int updateWeixiu(Weixiu weixiu)
    {
        return weixiuMapper.updateWeixiu(weixiu);
    }

    /**
     * 批量删除维修相关信息
     *
     * @param ids 需要删除的维修相关信息主键
     * @return 结果
     */
    @Override
    public int deleteWeixiuByIds(Long[] ids)
    {
        return weixiuMapper.deleteWeixiuByIds(ids);
    }

    /**
     * 删除维修相关信息信息
     *
     * @param id 维修相关信息主键
     * @return 结果
     */
    @Override
    public int deleteWeixiuById(Long id)
    {
        return weixiuMapper.deleteWeixiuById(id);
    }
}
