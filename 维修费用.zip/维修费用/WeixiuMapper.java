package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.Weixiu;

/**
 * 维修相关信息Mapper接口
 *
 * @author ruoyi
 * @date 2025-04-07
 */
public interface WeixiuMapper
{
    /**
     * 查询维修相关信息
     *
     * @param id 维修相关信息主键
     * @return 维修相关信息
     */
    public Weixiu selectWeixiuById(Long id);

    /**
     * 查询维修相关信息列表
     *
     * @param weixiu 维修相关信息
     * @return 维修相关信息集合
     */
    public List<Weixiu> selectWeixiuList(Weixiu weixiu);

    /**
     * 新增维修相关信息
     *
     * @param weixiu 维修相关信息
     * @return 结果
     */
    public int insertWeixiu(Weixiu weixiu);

    /**
     * 修改维修相关信息
     *
     * @param weixiu 维修相关信息
     * @return 结果
     */
    public int updateWeixiu(Weixiu weixiu);

    /**
     * 删除维修相关信息
     *
     * @param id 维修相关信息主键
     * @return 结果
     */
    public int deleteWeixiuById(Long id);

    /**
     * 批量删除维修相关信息
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteWeixiuByIds(Long[] ids);
}
