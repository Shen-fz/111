<template>
  <view class="container">
    <view class="form-item">
      <label>业主姓名：</label>
      <input v-model="formData.ownerName" placeholder="请输入业主姓名" />
    </view>
    <view class="form-item">
      <label>房号：</label>
      <input v-model="formData.roomNumber" placeholder="请输入房号" />
    </view>
    <view class="form-item">
      <label>维修项目：</label>
      <input v-model="formData.repairProject" placeholder="请输入维修项目" />
    </view>
    <view class="form-item">
      <label>缴费金额：</label>
      <input v-model="formData.paymentAmount" placeholder="请输入缴费金额" type="number" />
    </view>
    <button @click="submitForm">提交缴费</button>
  </view>
</template>

<script>
import { addWeixiu } from '../../api/system/weixiu.js';

export default {
  data() {
    return {
      formData: {
        ownerName: '',
        roomNumber: '',
        repairProject: '',
        paymentAmount: ''
      }
    };
  },
  methods: {
    submitForm() {
      const { ownerName, roomNumber, repairProject, paymentAmount } = this.formData;
      if (!ownerName || !roomNumber || !repairProject || !paymentAmount) {
        uni.showToast({
          title: '请填写完整信息',
          icon: 'none'
        });
        return;
      }
      addWeixiu(this.formData)
        .then(response => {
          // 处理成功响应
          console.log('提交成功', response);
          uni.showToast({
            title: '提交成功',
            icon: 'success'
          });
          // 清空表单
          this.formData = {
            ownerName: '',
            roomNumber: '',
            repairProject: '',
            paymentAmount: ''
          };
        })
        .catch(error => {
          // 处理错误响应
          console.error('提交失败', error);
          uni.showToast({
            title: '提交失败',
            icon: 'none'
          });
        });
    }
  }
};
</script>

<style>
.container {
  padding: 20px;
}
.form-item {
  margin-bottom: 15px;
}
label {
  display: block;
  margin-bottom: 5px;
}
input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}
button {
  width: 100%;
  padding: 10px;
  background-color: #007aff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}
</style>