package com.ruoyi.web.controller.system;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.Weixiu;
import com.ruoyi.system.service.IWeixiuService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 维修相关信息Controller
 *
 * @author ruoyi
 * @date 2025-04-07
 */
@RestController
@RequestMapping("/system/weixiu")
public class WeixiuController extends BaseController
{
    @Autowired
    private IWeixiuService weixiuService;

    /**
     * 查询维修相关信息列表
     */
    @PreAuthorize("@ss.hasPermi('system:weixiu:list')")
    @GetMapping("/list")
    public TableDataInfo list(Weixiu weixiu)
    {
        startPage();
        List<Weixiu> list = weixiuService.selectWeixiuList(weixiu);
        return getDataTable(list);
    }

    /**
     * 导出维修相关信息列表
     */
    @PreAuthorize("@ss.hasPermi('system:weixiu:export')")
    @Log(title = "维修相关信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Weixiu weixiu)
    {
        List<Weixiu> list = weixiuService.selectWeixiuList(weixiu);
        ExcelUtil<Weixiu> util = new ExcelUtil<Weixiu>(Weixiu.class);
        util.exportExcel(response, list, "维修相关信息数据");
    }

    /**
     * 获取维修相关信息详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:weixiu:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(weixiuService.selectWeixiuById(id));
    }

    /**
     * 新增维修相关信息
     */
    @PreAuthorize("@ss.hasPermi('system:weixiu:add')")
    @Log(title = "维修相关信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Weixiu weixiu)
    {
        return toAjax(weixiuService.insertWeixiu(weixiu));
    }

    /**
     * 修改维修相关信息
     */
    @PreAuthorize("@ss.hasPermi('system:weixiu:edit')")
    @Log(title = "维修相关信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Weixiu weixiu)
    {
        return toAjax(weixiuService.updateWeixiu(weixiu));
    }

    /**
     * 删除维修相关信息
     */
    @PreAuthorize("@ss.hasPermi('system:weixiu:remove')")
    @Log(title = "维修相关信息", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(weixiuService.deleteWeixiuByIds(ids));
    }
}
