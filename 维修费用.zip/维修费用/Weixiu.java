package com.ruoyi.system.domain;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 维修相关信息对象 weixiu
 *
 * @author ruoyi
 * @date 2025-04-07
 */
public class Weixiu extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private Long id;

    /** 业主姓名 */
    @Excel(name = "业主姓名")
    private String ownerName;

    /** 房号 */
    @Excel(name = "房号")
    private String roomNumber;

    /** 维修项目 */
    @Excel(name = "维修项目")
    private String repairProject;

    /** 缴费金额 */
    @Excel(name = "缴费金额")
    private BigDecimal paymentAmount;

    /** 记录日期 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "记录日期", width = 30, dateFormat = "yyyy-MM-dd")
    private Date recordDate;

    public void setId(Long id)
    {
        this.id = id;
    }

    public Long getId()
    {
        return id;
    }

    public void setOwnerName(String ownerName)
    {
        this.ownerName = ownerName;
    }

    public String getOwnerName()
    {
        return ownerName;
    }

    public void setRoomNumber(String roomNumber)
    {
        this.roomNumber = roomNumber;
    }

    public String getRoomNumber()
    {
        return roomNumber;
    }

    public void setRepairProject(String repairProject)
    {
        this.repairProject = repairProject;
    }

    public String getRepairProject()
    {
        return repairProject;
    }

    public void setPaymentAmount(BigDecimal paymentAmount)
    {
        this.paymentAmount = paymentAmount;
    }

    public BigDecimal getPaymentAmount()
    {
        return paymentAmount;
    }

    public void setRecordDate(Date recordDate)
    {
        this.recordDate = recordDate;
    }

    public Date getRecordDate()
    {
        return recordDate;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("id", getId())
                .append("ownerName", getOwnerName())
                .append("roomNumber", getRoomNumber())
                .append("repairProject", getRepairProject())
                .append("paymentAmount", getPaymentAmount())
                .append("recordDate", getRecordDate())
                .toString();
    }
}
