## 1.1.1（2022-05-19）
- 修改组件描述
## 1.1.0（2021-11-19）
- 优化 组件UI，并提供设计资源，详见:[https://uniapp.dcloud.io/component/uniui/resource](https://uniapp.dcloud.io/component/uniui/resource)
- 文档迁移，详见:[https://uniapp.dcloud.io/component/uniui/uni-title](https://uniapp.dcloud.io/component/uniui/uni-title)
## 1.0.2（2021-05-12）
- 新增 示例地址
- 修复 示例项目缺少组件的Bug
## 1.0.1（2021-02-05）
- 调整为uni_modules目录规范
