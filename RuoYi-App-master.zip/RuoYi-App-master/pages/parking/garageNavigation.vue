<template>
	<!-- pages/garageNavigation/garageNavigation.wxml -->
	<view class="container">
		<map id="garageMap" style="width: 100%; height: 300px;" :latitude="latitude" :longitude="longitude"
			:markers="markers" show-location>


		</map>
		<button @tap="navigateToGarage">导航至车库</button>
		<button @click="toGaragePay">导航完成，点击缴费</button>
	</view>

</template>

<script>
	export default {
		data() {
			return {
				latitude: 39.9042, // 示例纬度，应替换为实际车库纬度
				longitude: 116.4074, // 示例经度，应替换为实际车库经度
				markers: [{
					id: 0,
					latitude: 39.9042,
					longitude: 116.4074,
					title: '我的车库',
					iconPath: '', // 替换为你的车库图标路径
					width: 50,
					height: 50
				}]
			}
		},
		onLoad(options) {
			this.vc.onLoad(options)
		},
		methods: {
			navigateToGarage: function() {
				wx.openLocation({
					latitude: this.data.latitude,
					longitude: this.data.longitude,
					name: '我的车库',
					address: '车库详细地址',
					scale: 18
				})
			},
			toGaragePay: function() {
				setTimeout(() => {
					wx.navigateTo({
						url: '/pages/parking/parkingCharge'
					});
				}, 2000);
			}
		}
	}
</script>

<style>
	.container {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		height: 100%;
	}

	button {
		margin-top: 20px;
		width: 90%;
	}
</style>