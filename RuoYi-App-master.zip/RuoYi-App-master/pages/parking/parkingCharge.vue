<template>
	<view class="container">
		<view class="input-group">
			<view class="input-row">
				<text class="label">入场时间:</text>
				<input type="time" :value="startTime" bindinput="bindStartTimeInput" />
			</view>
			<view class="input-row">
				<text class="label">出场时间:</text>
				<input type="time"  :value="endTime" bindinput="bindEndTimeInput" />
			</view>
		</view>
		<button @tap="calculateCharge">计算费用</button>
		<view class="result" v-if="showResult">
			<text>停车时长: {{parkingDuration}}小时</text>
			<text>停车费用: {{parkingCharge}}元</text>
			<button @tap="payCharge">支付</button>
		</view>
	</view>

</template>

<script>
	// pages/parkingCharge/parkingCharge.js
	Page({
	  data: {
	    startTime: '08:00',
	    endTime: '18:00',
	    parkingDuration: 0,
	    parkingCharge: 0,
	    showResult: false,
	    rate: 10 // 假设每小时收费10元
	  },
	  bindStartTimeInput: function(e) {
	    this.setData({
	      startTime: e.detail.value
	    });
	  },
	  bindEndTimeInput: function(e) {
	    this.setData({
	      endTime: e.detail.value
	    });
	  },
	  calculateCharge: function() {
	    const start = this.data.startTime.split(':');
	    const end = this.data.endTime.split(':');
	    const startTime = new Date(0, 0, 0, start[0], start[1], 0);
	    const endTime = new Date(0, 0, 0, end[0], end[1], 0);
	    const duration = (endTime - startTime) / 3600000; // 转换为小时
	    const charge = duration * this.data.rate;
	    this.setData({
	      parkingDuration: duration.toFixed(2),
	      parkingCharge: charge.toFixed(2),
	      showResult: true
	    });
	  },
	  payCharge: function() {
	    // 这里可以调用支付接口进行支付
	    wx.showToast({
	      title: '支付成功',
	      icon: 'success'
	    });
	    // 支付成功后的逻辑处理
	    this.setData({
	      showResult: false
	    });
	  }
	});
</script>

<style>
	.container {
		padding: 20px;
	}

	.input-group {
		margin-bottom: 20px;
	}

	.input-row {
		display: flex;
		margin-bottom: 10px;
	}

	.label {
		width: 100px;
	}

	.result {
		margin-top: 20px;
	}
</style>