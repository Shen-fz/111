<template>
	<view class="container">
		<view class="title">寻找车库</view>
		<view v-if="loading">
			<text>加载中...</text>
		</view>
		<view v-else>
			<button class="find-garage-btn" @tap="findGarage" :disabled="loading">寻找附近车库</button>
			<map id="garageMap" style="width: 100%; height: 300px;" :latitude="latitude" :longitude="longitude"
				:markers="markers" show-location>
			</map>
		</view>
	</view>

</template>

<script>
	export default {
		data() {
			return {
				latitude: 0, // 初始纬度
				longitude: 0, // 初始经度
				markers: [], // 地图上的标记点
				loading: false // 加载状态
			};
		},
		onLoad() {
			this.getLocation();
		},
		methods: {
			getLocation() {
				this.loading = true;
				wx.getLocation({
					type: 'gcj02', // 返回可以用于wx.openLocation的经纬度
					success: (res) => {
						this.latitude = res.latitude;
						this.longitude = res.longitude;
					},
					fail: (err) => {
						console.error('获取位置失败', err);
						wx.showToast({
							title: '获取位置失败，请检查设置',
							icon: 'none'
						});
					},
					complete: () => {
						this.loading = false;
					}
				});
			},
			findGarage() {
				if (this.loading) return;
				this.loading = true;
				// 实际应用中，这里应该调用后端API来获取附近车库的位置信息
				// 以下是模拟数据
				const markers = [{
						id: 0,
						latitude: this.latitude + 0.01,
						longitude: this.longitude + 0.01,
						title: '车库A',
						iconPath: '/static/images/qe.png', // 车库标记图标
						width: 50,
						height: 50
					}
					// 可以添加更多车库标记
				];
				this.markers = markers;
				this.loading = false;
			}
		}
	};
</script>

<style>
	.container {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		height: 100%;
	}

	.title {
		font-size: 18px;
		margin-bottom: 20px;
	}

	.find-garage-btn {
		width: 80%;
		margin-bottom: 10px;
	}
</style>