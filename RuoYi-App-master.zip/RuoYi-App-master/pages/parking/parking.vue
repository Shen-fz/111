<template>
	<view class="">
		<view class="container">
			<button @tap="oneKeyParking" class="parking-btn" >一键停车</button>
			<button @tap="findGarageo" class="parking-btn" @click="findGarageo(item)">寻找车库</button>
			<button @tap="startNavigation" class="parking-btn" @click="startNavigation(item)">开始导航</button>
			<button @tap="payForParking" class="parking-btn" @click="payForParking(item)">支付停车费</button>
			<button @tap="autoFindCar" class="parking-btn" @click="autoFindCar(item)">自动寻车</button>

		</view>

	</view>

</template>

<script>
	export default {
		data() {
			return {
				// 专区目录类型
				selectCommunityName: "",

			}
		},
		onLoad(options) {
			this.vc.onLoad(options)
		},
		methods: {
			oneKeyParking: function() {
				// 逻辑处理，如发送请求到后端进行车位分配等
				wx.showToast({
					title: '正在为您分配车位...',
					icon: 'loading'
				});
				// 假设分配成功
				setTimeout(() => {
					wx.navigateTo({
						url: '/pages/findGarage/findGarage'
					});
				}, 2000);
			},
			findGarageo: function() {
				wx.navigateTo({
					url: '/pages/parking/findGarage'
				});
				// 逻辑处理，如调用地图API寻找最近的车库
				wx.showToast({
					title: '正在为您查找最近的车库...',
					icon: 'loading'
				});
				// 假设找到车库
				// setTimeout(() => {
				// 	wx.navigateTo({
				// 		url: '/pages/parking/garageNavigation'
				// 	});
				// }, 2000);
			},
			payForParking: function() {
				wx.navigateTo({
					url: '/pages/parking/parkingCharge'
				});
			
				// 逻辑处理，如调用支付API进行支付
				wx.showToast({
					title: '正在为您支付停车费...',
					icon: 'loading'
				});
				// 假设支付成功
				setTimeout(() => {
					wx.navigateTo({
						url: '/pages/parking/parking'
					});
				}, 2000);
			},
			autoFindCar: function() {
				// 逻辑处理，如调用定位API找到车辆位置
				wx.showToast({
					title: '正在为您寻找车辆...',
					icon: 'loading'
				});
				// 假设找到车辆
				setTimeout(() => {
					wx.showToast({
						title: '您的车辆位置已找到',
						icon: 'success'
					});
				}, 2000);
			},
			startNavigation: function() {
				wx.navigateTo({
					url: '/pages/parking/garageNavigation'
				});
				// 逻辑处理，如调用地图API进行导航
				wx.showToast({
					title: '正在为您导航...',
					icon: 'loading'
				});
				// 假设导航成功
				// setTimeout(() => {
				// 	wx.navigateTo({
				// 		url: '/pages/parking/parkingCharge'
				// 	});
				// }, 2000);
			}
			// goPay(e) {
			// 	uni.navigateTo({
			// 		url: "/pages/parking/findGarage"
			// 		// animationDuration: 500
			// 	})
			// }
		}
	}

	Page({



		








		
	});
</script>

<style>
	/* pages/parking/parking.wxss */
	.container {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		height: 100%;
		margin-top: 20%;
	}

	.parking-btn {
		width: 80%;
		background-color: #1AAD19;
		color: white;
		border-radius: 5px;
		padding: 10px;
		text-align: center;
		margin-top: 10px;
	}
</style>