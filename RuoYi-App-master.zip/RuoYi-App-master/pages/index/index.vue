<template>
	<view class="page">

		<!-- 轮播图 -->
		<view class="swiper-container">
			<swiper autoplay="true" interval="3000" duration="500" indicator-dots="true" circular="true">
				<swiper-item>
					<image src="/static/logo200.png" class="slide-image" mode="aspectFill" />
				</swiper-item>
				<swiper-item>
					<image src="/static/logo200.png" class="slide-image" mode="aspectFill" />
				</swiper-item>
				<swiper-item>
					<image src="/static/logo200.png" class="slide-image" mode="aspectFill" />
				</swiper-item>
			</swiper>
		</view>

		<view class="content-all">
			<view class="content">
				<view class="text-area">
					<text class="title">Hello RuoYi</text>
				</view>
			</view>

			<view class="content">
				<view class="text-area">
					<text class="title">Hello RuoYi</text>
				</view>
			</view>

			<view class="content">
				<view class="text-area">
					<text class="title">Hello RuoYi</text>
				</view>
			</view>
		</view>

		<view class="services">
			<view class="servertitle">
				功能服务
				<text class="more" @click="goMore(item)">更多</text>
			</view>
			<view class="server_list">
				<view class="server_item" @click="goWyMoney(item)">
					<image class="fourt" src="http://wuye.taksongroup.com/h5/images/serve/1.png"></image>
					<!-- <img src="../../static/images/qe.png" alt="" /> -->
					<view class="text">
						物业缴费
					</view>
				</view>
				<view class="server_item" @click="goRpMoney(item)">
					<image class="fourt" src="http://wuye.taksongroup.com/h5/images/serve/5.png"></image>
					<view class="text">
						维修费用
					</view>
				</view>
				<view class="server_item" @click="goParking(item)">
					<image class="fourt" src="http://wuye.taksongroup.com/h5/images/serve/9.png"></image>
					<view class="text">
						停车费
					</view>
				</view>
				<view class="server_item" @click="goDrControl(item)">
					<image class="fourt" src="http://wuye.taksongroup.com/h5/images/serve/8.png"></image>
					<view class="text">
						一键开门
					</view>
				</view>
			</view>

		</view>
		<view class="new_box">
			<view class="top_one">
				<view class="notic">
					<image class="not" src="/static/images/notice.png"></image>
				</view>
				<view class="margin-top">
					<view class="marquee">这是一个无限滚动的文本示例，文本会从右到左不断滚动。</view>
				</view>
			</view>

			<view class="double_server">
				<view class="new_list">
					<view class="new_item">
						<view class="container" @click="goRepair(item)">
							<view class="new_font">
								<view class="repair-btn" bindtap="navigateToRepair">物业报修</view>
								<view class="repair-text" bindtap="navigateToRepair">一键维修</view>
							</view>
							<!-- <view class="server_left"> -->
							<image class="repair-image" src="/static/images/qe.png"></image>
							<!-- </view> -->
						</view>
					</view>
					<view class="new_item">
						<view class="container" @click="goRepair_t(item)">
							<view class="new_font">
								<view class="repair-btn" bindtap="navigateToRepair">联系物业</view>
								<view class="repair-text" bindtap="navigateToRepair">一键搞定</view>
							</view>
							<image class="repair-image" src="/static/images/qe.png"></image>
						</view>
					</view>
				</view>
			</view>
		</view>

		<view class="active_f">
			<view class="active_d">
				<view class="active_title">
					社区活动
				</view>
				<view class="active_text">
					<view class="text_title" @tab-click="handleClick" v-model="activeName">
						<view label="公寓公告" class="title_left" :class="{ active: activeName === 'first' }" name="first"
							@click="switchTab('first')">
							公寓公告
						</view>
						<view label="租赁信息" class="title_left" :class="{ active: activeName === 'second' }" name="second"
							@click="switchTab('second')">
							租赁信息
						</view>
					</view>
					<view class="test_list" v-show="activeName === 'first'">
						<view class="noticeList" @click="newNotice">
							<view class="notices_info">
								<view class="notices_info_name">
									全“新”交付 | 与佛山，开启美好办公生活
								</view>
								<view class="notices_bottom">
									<view class="">
										<text class="texto_left">

										</text>
										<text class="texto_right">
											2025/03/30
										</text>
									</view>
								</view>
							</view>
							<view>
								<image class="notices_img" src="/static/images/qe.png"></image>
							</view>
						</view>
					</view>
					<view class="test_list" v-show="activeName === 'second'">
						<view class="active_empty">
							<image src="http://demo.homecommunity.cn//h5/images/serve/empty.png" class="image_empty"></image>
							<text class="text_empty">暂无活动哦~</text>
						</view>
					</view>
				</view>
			</view>
		</view>

	</view>

</template>

<script>
	// Page({
	// 	navigateToRepair: function() {
	// 		wx.navigateTo({
	// 			url: '/pages/repair/repair'
	// 		})
	// 	}
	// })

	export default {

		data() {
			return {
				activeName: 'first'
			};
		},

		onLoad() {

		},
		methods: {
			goRepair(e) {
				uni.navigateTo({
					url: "/pages/repair/repair"
					// animationDuration: 500
				})
			},
			goRepair_t(e) {
				uni.navigateTo({
					url: "/pages/contact/contact"
					// animationDuration: 500
				})
			},

			switchTab(tabName) {
				this.activeName = tabName;
			},

			// switchTab(index) {
			//   // 获取所有标签项和内容项
			//   var tabItems = document.getElementsByClassName('title_left');
			//   var contents = document.getElementsByClassName('test_list');

			//   // 遍历标签项，移除active类
			//   for (var i = 0; i < tabItems.length; i++) {
			//     tabItems[i].classList.remove('active');
			//     contents[i].classList.remove('active');
			//   }

			//   // 为当前点击的标签项和对应的内容项添加active类
			//   tabItems[index].classList.add('active');
			//   contents[index].classList.add('active');
			// },

			handleClick(tab, event) {
				console.log(tab, event);
			},
			goMore(e) {
				uni.switchTab({
					url: "/pages/work/index"
				})
			},
			goWyMoney(e) {
				uni.navigateTo({
					url: "/pages/money/money"
					// animationDuration: 500
				})
			},
			goRpMoney(e) {
				uni.navigateTo({
					url: "/pages/maintenance/maintenance"
					// animationDuration: 500
				})
			},
			goParking(e) {
				uni.navigateTo({
					url: "/pages/parking/parking"
					// animationDuration: 500
				})
			},
			goDrControl(e) {
				uni.navigateTo({
					url: "/pages/doorControl/doorControl"
					// animationDuration: 500
				})
			},
			newNotice(e){
				uni.navigateTo({
					url: "/pages/noticeDetail/noticeDetail"
					// animationDuration: 500
				})
			}
		}
	}
</script>

<style scoped>
	@import "./index.css";

	.content-all {
		width: 100%;
		display: flex;
		padding: 10rpx;
		margin-right: 20rpx;
		/* background: #fff; */
		text-align: center;
		align-items: center;
		border-radius: 5rpx;
		font-size: 28rpx;
	}

	.content {
		/* display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center; */
		padding: 20rpx;
		width: calc((100% - 40rpx) / 3);
		margin-right: 20rpx;
		background: #fff;
		text-align: center;
		display: flex;
		align-items: center;
		border-radius: 5rpx;
		font-size: 28rpx;
	}

	.text-area {
		display: flex;
		/* justify-content: center; */
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}

	.swiper-container {
		width: 100%;
		height: 200px;
		/* 根据实际需求调整高度 */
		margin: 0 auto;
		margin-top: 10px;
	}

	.slide-image {
		width: 100%;
		height: 100%;
	}

	.services {
		width: 100%;
		padding: 0 20rpx;
		background: #fff;
		margin-bottom: 20rpx;
	}

	.servertitle {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 20rpx 0;
		font-size: 30rpx;
		font-weight: 600;
		text-align: justify;
	}

	.more {
		font-size: 24rpx;
		font-weight: 400;
		color: #999;
	}

	.server_list {
		border-radius: 5px;
		margin: 0;
		display: block;
	}

	/* .server_list, */
	.server_item {
		/* height: 70px; */
		display: inline-block;
		padding: 20px;
		width: 25%;
		/* height: 25%; */
		text-align: center;
		font-size: 28rpx;
	}

	.fourt {
		height: 40px;
		max-width: 100%;
		display: inline-block;
		position: relative;
		z-index: 0;
	}

	.text {
		white-space: nowrap;
		font-size: 25rpx;
		font-weight: 400;
	}
</style>