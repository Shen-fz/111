<template>
	<!-- pages/payProperty/payProperty.wxml -->
	<view class="container">
		<view class="title">物业缴费</view>
		<form bindsubmit="submitPayment">
			<view class="form-item">
				<text class="label">业主姓名：</text>
				<input class="input" name="ownerName" placeholder="请输入业主姓名" />
			</view>
			<view class="form-item">
				<text class="label">房号：</text>
				<input class="input" name="roomNumber" placeholder="请输入房号" />
			</view>
			<view class="form-item">
				<text class="label">缴费金额：</text>
				<input class="input" type="number" name="amount" placeholder="请输入缴费金额" />
			</view>
			<view class="form-item">
				<text class="label">缴费月份：</text>
				<picker mode="date" fields="month" name="paymentMonth" bindchange="bindDateChange">
					<view class="picker">
						{{paymentMonth}}
					</view>
				</picker>
			</view>
			<button formType="submit" class="submit-btn">确认缴费</button>
		</form>
	</view>

</template>

<script>
	// pages/payProperty/payProperty.js
	Page({
		data: {
			paymentMonth: '选择缴费月份'
		},
		bindDateChange: function(e) {
			this.setData({
				paymentMonth: e.detail.value
			});
		},
		submitPayment: function(e) {
			const {
				ownerName,
				roomNumber,
				amount,
				paymentMonth
			} = e.detail.value;
			if (!ownerName || !roomNumber || !amount || paymentMonth === '选择缴费月份') {
				wx.showToast({
					title: '请填写完整信息',
					icon: 'none'
				});
				return;
			}
			// 在这里可以调用后端接口进行缴费操作
			wx.showToast({
				title: '缴费成功',
				icon: 'success'
			});
		}
	});
</script>

<style>
	/* pages/payProperty/payProperty.wxss */
	.container {
		padding: 20px;
	}

	.title {
		font-size: 18px;
		font-weight: bold;
		text-align: center;
		margin-bottom: 20px;
	}

	.form-item {
		margin-bottom: 10px;
	}

	.label {
		display: inline-block;
		width: 80px;
	}

	.input {
		border: 1px solid #ddd;
		padding: 5px;
		border-radius: 4px;
	}

	.picker {
		border: 1px solid #ddd;
		padding: 5px;
		border-radius: 4px;
	}

	.submit-btn {
		background-color: #007aff;
		color: #fff;
		border-radius: 4px;
		padding: 10px;
		text-align: center;
		margin-top: 20px;
	}
</style>