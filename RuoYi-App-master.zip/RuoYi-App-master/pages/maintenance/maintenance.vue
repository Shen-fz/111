<template>
	<view class="container">
	  <view class="title">小区维修交费</view>
	  <form bindsubmit="submitPayment">
	    <view class="form-item">
	      <text class="label">业主姓名：</text>
	      <input class="input" name="ownerName" placeholder="请输入业主姓名" />
	    </view>
	    <view class="form-item">
	      <text class="label">房号：</text>
	      <input class="input" name="roomNumber" placeholder="请输入房号" />
	    </view>
	    <view class="form-item">
	      <text class="label">维修项目：</text>
	      <input class="input" name="repairItem" placeholder="请输入维修项目" />
	    </view>
	    <view class="form-item">
	      <text class="label">缴费金额：</text>
	      <input class="input" type="number" name="amount" placeholder="请输入缴费金额" />
	    </view>
	    <button formType="submit" class="submit-btn">提交缴费</button>
	  </form>
	</view>

</template>

<script>
	// pages/repairPayment/repairPayment.js
	Page({
	  data: {
	    // 可以在这里添加一些初始化数据
	  },
	  submitPayment: function(e) {
	    const { ownerName, roomNumber, repairItem, amount } = e.detail.value;
	    if (!ownerName || !roomNumber || !repairItem || !amount) {
	      wx.showToast({
	        title: '请填写完整信息',
	        icon: 'none'
	      });
	      return;
	    }
	    
	    // 在这里可以调用后端接口进行缴费操作
	    // 示例代码，实际开发中需要替换为真实的请求
	    wx.request({
	      url: 'https://your-backend-api.com/repair-payment', // 替换为你的后端接口地址
	      method: 'POST',
	      data: {
	        ownerName,
	        roomNumber,
	        repairItem,
	        amount
	      },
	      success: function(res) {
	        if (res.data.success) {
	          wx.showToast({
	            title: '缴费成功',
	            icon: 'success'
	          });
	        } else {
	          wx.showToast({
	            title: '缴费失败，请稍后再试',
	            icon: 'none'
	          });
	        }
	      },
	      fail: function() {
	        wx.showToast({
	          title: '网络错误，请检查网络连接',
	          icon: 'none'
	        });
	      }
	    });
	  }
	});

</script>

<style>
	/* pages/repairPayment/repairPayment.wxss */
	.container {
	  padding: 20px;
	}
	
	.title {
	  font-size: 18px;
	  font-weight: bold;
	  text-align: center;
	  margin-bottom: 20px;
	}
	
	.form-item {
	  margin-bottom: 10px;
	}
	
	.label {
	  display: inline-block;
	  width: 100px;
	}
	
	.input {
	  border: 1px solid #ddd;
	  padding: 5px;
	  border-radius: 4px;
	}
	
	.submit-btn {
	  width: 100%;
	  background-color: #1AAD19;
	  color: white;
	  border-radius: 4px;
	  padding: 10px;
	  margin-top: 20px;
	}

</style>