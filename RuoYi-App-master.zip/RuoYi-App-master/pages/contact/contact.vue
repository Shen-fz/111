<template>
	<view class="container">
	  <form bindsubmit="submitForm">
	    <view class="input-group">
	      <text class="label">姓名：</text>
	      <input name="name" class="input" placeholder="请输入您的姓名" />
	    </view>
	    <view class="input-group">
	      <text class="label">电话：</text>
	      <input name="phone" class="input" type="number" placeholder="请输入您的电话" />
	    </view>
	    <view class="input-group">
	      <text class="label">问题描述：</text>
	      <textarea name="description" class="textarea" placeholder="请描述您的问题" />
	    </view>
	    <button formType="submit" class="submit-btn">提交</button>
	  </form>
	</view>

</template>

<script>
	Page({
	  data: {
	    // 可以在这里初始化一些数据
	  },
	  submitForm: function(e) {
	    // 获取表单数据
	    const formData = e.detail.value;
	    
	    // 这里可以添加代码将数据提交到服务器
	    // 例如使用 wx.request 发送数据到后端API
	    console.log(formData);
	    
	    // 提示用户提交成功
	    wx.showToast({
	      title: '提交成功',
	      icon: 'success',
	      duration: 2000
	    });
	  }
	});

</script>

<style>
	.container {
	  padding: 20px;
	}
	
	.input-group {
	  margin-bottom: 20px;
	}
	
	.label {
	  display: block;
	  margin-bottom: 10px;
	}
	
	.input,
	.textarea {
	  width: 100%;
	  border: 1px solid #ddd;
	  border-radius: 4px;
	  padding: 10px;
	}
	
	.textarea {
	  height: 150px;
	}
	
	.submit-btn {
	  width: 100%;
	  background-color: #1AAD19;
	  color: white;
	  border: none;
	  border-radius: 4px;
	  padding: 10px;
	  text-align: center;
	}

</style>