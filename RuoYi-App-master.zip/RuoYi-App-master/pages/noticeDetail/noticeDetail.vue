<template>
	<view class="container">
		<view class="notice-list">
			<block v-for="(item, index) in notices" :key="index">
				<view class="notice-item" bindtap="goToDetail" :data-index="index">
					<view class="notice-title">{{item.title}}</view>
					<view class="notice-date">{{item.date}}</view>
					<view class="notice-summary">{{item.summary}}</view>
				</view>
			</block>
		</view>
	</view>

</template>

<script>
	export default {
	    data() {
	        return {
	            notices: [
	                {
	                    title: '春季促销活动',
	                    date: '2023-04-01',
	                    summary: '春季新品上市，全场8折优惠。',
	                    detail: '更多春季新品信息，请点击查看详情。'
	                },
	                {
	                    title: '会员日特惠',
	                    date: '2023-04-08',
	                    summary: '会员专享，全场9折优惠。',
	                    detail: '会员日特惠，不要错过！'
	                }
	                // 更多通知...
	            ]
	        };
	    },
	    methods: {
	        goToDetail(index) {
	            const notice = this.notices[index];
	            wx.navigateTo({
	                url: `/pages/noticeDetail/noticeDetail?title=${notice.title}&detail=${notice.detail}`
	            });
	        }
	    }
	};
	// Page({
	// 	data: {
	// 		notices: [{
	// 				title: '春季促销活动',
	// 				date: '2023-04-01',
	// 				summary: '春季新品上市，全场8折优惠。',
	// 				detail: '更多春季新品信息，请点击查看详情。'
	// 			},
	// 			{
	// 				title: '会员日特惠',
	// 				date: '2023-04-08',
	// 				summary: '会员专享，全场9折优惠。',
	// 				detail: '会员日特惠，不要错过！'
	// 			},
	// 			// 更多通知...
	// 		]
	// 	},
	// 	goToDetail: function(e) {
	// 		const index = e.currentTarget.dataset.index;
	// 		const notice = this.data.notices[index];
	// 		wx.navigateTo({
	// 			url: '/pages/noticeDetail/noticeDetail?title=' + notice.title + '&detail=' + notice
	// 				.detail
	// 		});
	// 	}
	// });
</script>

<style>
	.container {
		padding: 20rpx;
	}

	.notice-list {
		background-color: #ffffff;
	}

	.notice-item {
		border-bottom: 1rpx solid #e5e5e5;
		padding: 20rpx;
		cursor: pointer;
	}

	.notice-title {
		font-size: 34rpx;
		color: #333333;
	}

	.notice-date {
		font-size: 28rpx;
		color: #999999;
		margin-top: 10rpx;
	}

	.notice-summary {
		font-size: 30rpx;
		color: #666666;
		margin-top: 10rpx;
	}
</style>