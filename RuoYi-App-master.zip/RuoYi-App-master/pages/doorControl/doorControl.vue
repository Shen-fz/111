<template>
	<!-- pages/doorControl/doorControl.wxml -->
	<view class="container">
		<view class="title">门禁控制</view>
		<button class="door-btn" bindtap="openMainGate">打开小区大门</button>
		<button class="door-btn" bindtap="openHouseDoor">打开房屋门</button>
	</view>

</template>

<script>
	// pages/doorControl/doorControl.js
	Page({
		data: {
			// 可以在这里添加一些状态数据，比如门的开关状态
		},
		openMainGate: function() {
			// 这里应该调用后端接口来控制小区大门的开关
			// 示例代码，需要替换为实际的后端接口调用
			wx.showLoading({
				title: '正在打开大门...',
			});
			wx.request({
				url: 'https://your-backend-api.com/open-main-gate', // 替换为你的后端接口地址
				method: 'POST',
				success: function(res) {
					wx.hideLoading();
					if (res.data.success) {
						wx.showToast({
							title: '大门已打开',
							icon: 'success'
						});
					} else {
						wx.showToast({
							title: '开门失败，请稍后再试',
							icon: 'none'
						});
					}
				},
				fail: function() {
					wx.hideLoading();
					wx.showToast({
						title: '网络错误，请检查网络连接',
						icon: 'none'
					});
				}
			});
		},
		openHouseDoor: function() {
			// 这里应该调用后端接口来控制房屋门的开关
			// 示例代码，需要替换为实际的后端接口调用
			wx.showLoading({
				title: '正在打开房门...',
			});
			wx.request({
				url: 'https://your-backend-api.com/open-house-door', // 替换为你的后端接口地址
				method: 'POST',
				success: function(res) {
					wx.hideLoading();
					if (res.data.success) {
						wx.showToast({
							title: '房门已打开',
							icon: 'success'
						});
					} else {
						wx.showToast({
							title: '开门失败，请稍后再试',
							icon: 'none'
						});
					}
				},
				fail: function() {
					wx.hideLoading();
					wx.showToast({
						title: '网络错误，请检查网络连接',
						icon: 'none'
					});
				}
			});
		}
	});
</script>

<style>
	/* pages/doorControl/doorControl.wxss */
	.container {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		height: 100%;
	}

	.title {
		font-size: 18px;
		margin-bottom: 20px;
	}

	.door-btn {
		width: 80%;
		margin-top: 10px;
		background-color: #007aff;
		color: white;
	}
</style>